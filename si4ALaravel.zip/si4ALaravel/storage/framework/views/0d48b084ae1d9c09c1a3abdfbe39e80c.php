<?php $__env->startSection('title', 'Prodi'); ?>
<?php $__env->startSection('content'); ?>
    <!--begin::Row-->
    <div class="row">
        <div class="col-12">
            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">List Program Studi</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse" title="Collapse">
                            <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                            <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                        </button>
                        <button type="button" class="btn btn-tool" data-lte-toggle="card-remove" title="Remove">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <a href = "<?php echo e(route('prodi.create')); ?>" class="btn btn-primary">Tambah</a>
                    <table class="table table-bordered table-striped">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nama Prodi</th>
                                    <th>Singkatan</th>
                                    <th>Kaprodi</th>
                                    <th>Sekretaris</th>
                                    <th>Fakultas</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->nama); ?> </td>
                                        <td><?php echo e($item->singkatan); ?> </td>
                                        <td><?php echo e($item->kaprodi); ?> </td>
                                        <td><?php echo e($item->sekretaris); ?> </td>
                                        <td><?php echo e($item->fakultas->nama); ?> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                </div>
                <!-- /.card-body -->
                
                <!-- /.card-footer-->
            </div>
            <!-- /.card -->
        </div>
    </div>
    <!--end::Row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/prodi/index.blade.php ENDPATH**/ ?>