<?php $__env->startSection('title', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-12">
                <div class="card card-primary card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Tambah Fakultas</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->
                    <form action=<?php echo e(route('fakultas.store')); ?> method="POST">
                        <?php echo csrf_field(); ?>
                        <!--begin::Body-->
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Fakultas</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e(old('nama')); ?>">
                            </div>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="mb-3">
                                <label for="singkatan" class="form-label">Singkatan</label>
                                <input type="text" class="form-control" name="singkatan" value="<?php echo e(old('singkatan')); ?>">
                            </div>
                            <?php $__errorArgs = ['singkatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="mb-3">
                                <label for="dekan" class="form-label">Nama Dekan</label>
                                <input type="text" class="form-control" name="dekan" value="<?php echo e(old('dekan')); ?>">
                            </div>
                            <?php $__errorArgs = ['dekan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="mb-3">
                                <label for="wakil_dekan" class="form-label">Nama Wakil Dekan</label>
                                <input type="text" class="form-control" name="wakil_dekan"
                                    value="<?php echo e(old('wakil_dekan')); ?>">
                            </div>
                            <?php $__errorArgs = ['wakil_dekan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
            </div>
            <!-- /.card -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/fakultas/create.blade.php ENDPATH**/ ?>