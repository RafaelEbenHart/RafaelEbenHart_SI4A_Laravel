<h1>Fakultas</h1>

<table>
    <tr>
        <th>Nama</th>
        <th>Singkatan</th>
        <th>Dekan</th>
        <th>Wakil Dekan</th>
    </tr>
    <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->singkatan); ?></td>
            <td><?php echo e($item->dekan); ?></td>
            <td><?php echo e($item->wakil_dekan); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\Niory\si4ALaravel\resources\views/fakultas/index.blade.php ENDPATH**/ ?>