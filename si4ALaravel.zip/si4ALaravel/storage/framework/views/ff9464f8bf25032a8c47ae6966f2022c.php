<?php $__env->startSection('title', 'Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-12">
                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Lihat Mahasiswa</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse" title="Collapse">
                                <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-remove" title="Remove">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <table>
                            <tr>
                                <td colspan = "2">
                                    <img src="<?php echo e(asset('images/' . $mahasiswa->foto)); ?>"
                                        alt="foto dari <?php echo e($mahasiswa->nama); ?>" class="img-fluid br-20">
                                </td>
                            </tr>
                            <tr>
                                <th>Nama</th>
                                <td><?php echo e($mahasiswa->nama); ?></td>
                            </tr>
                            <tr>
                                <th>NPM</th>
                                <td><?php echo e($mahasiswa->npm); ?></td>
                            </tr>
                            <tr>
                                <th>Tempat,Tanggal Lahir</th>
                                <td><?php echo e($mahasiswa->tempat_lahir); ?>,<?php echo e($mahasiswa->tanggal_lahir); ?></td>
                            </tr>
                            <tr>
                                <th>Asal SMA</th>
                                <td><?php echo e($mahasiswa->asal_sma); ?></td>
                            </tr>
                            <tr>
                                <th>Program</th>
                                <td><?php echo e($mahasiswa->prodi->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Fakultas</th>
                                <td><?php echo e($mahasiswa->prodi->fakultas->nama); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/mahasiswa/show.blade.php ENDPATH**/ ?>