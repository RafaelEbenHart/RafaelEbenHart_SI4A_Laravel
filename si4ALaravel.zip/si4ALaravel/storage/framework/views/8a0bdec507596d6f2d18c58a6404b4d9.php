<h1>Prodi</h1>

<table>
    <tr>
        <th>Nama</th>
        <th>Singkatan</th>
        <th>Kaprodi</th>
        <th>Sekretaris</th>
        <th>Fakultas</th>
    </tr>
    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->singkatan); ?></td>
            <td><?php echo e($item->kaprodi); ?></td>
            <td><?php echo e($item->sekretaris); ?></td>
            <td><?php echo e($item->fakultas->nama ?? '-'); ?></td>
         </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\Niory\si4ALaravel\resources\views/prodi/index.blade.php ENDPATH**/ ?>