<?php $__env->startSection('title', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
<!--begin::Row-->
            <div class="row">
              <div class="col-12">
                <!-- Default box -->
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">List Fakultas</h3>
                    <div class="card-tools">
                      <button
                        type="button"
                        class="btn btn-tool"
                        data-lte-toggle="card-collapse"
                        title="Collapse"
                      >
                        <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                        <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                      </button>
                      <button
                        type="button"
                        class="btn btn-tool"
                        data-lte-toggle="card-remove"
                        title="Remove"
                      >
                        <i class="bi bi-x-lg"></i>
                      </button>
                    </div>
                  </div>
                  <div class="card-body">
                  <a href = "<?php echo e(route('fakultas.create')); ?>" class="btn btn-primary">Tambah</a>
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th>Nama Fakultas</th>
                          <th>Singkatan</th>
                          <th>Dekan</th>
                          <th>Wakil Dekan</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($item->nama); ?> </td>
                          <td><?php echo e($item->singkatan); ?> </td>
                          <td><?php echo e($item->dekan); ?> </td>
                          <td><?php echo e($item->wakil_dekan); ?></td>
                        <td>
                        <a href="<?php echo e(route('fakultas.show', $item->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('fakultas.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('fakultas.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger show_confirm"
                                data-toggle="tooltip" title='Delete'>Delete</button>

                            </form>
                        </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

</div>
                  <!-- /.card-body -->
                  
                  <!-- /.card-footer-->
                </div>
                <!-- /.card -->
              </div>
            </div>
            <!--end::Row-->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/fakultas/index.blade.php ENDPATH**/ ?>