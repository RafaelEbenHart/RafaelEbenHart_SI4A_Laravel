<?php $__env->startSection('title', 'Mahasiswa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-12">
                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">List Mahasiswa</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse" title="Collapse">
                                <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-remove" title="Remove">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-primary">Tambah</a>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Foto</th>
                                    <th>Nama</th>
                                    <th>NPM</th>
                                    <th>jenis Kelamin</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Asal Sma</th>
                                    <th>Prodi</th>
                                    <th>Fakultas</th>
                                    <th>Aksi</th>
                            </thead>
                            </tr>

                            <?php $__currentLoopData = $mahasiwa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="images/<?php echo e($item->foto); ?>" alt="foto dari <?php echo e($item->nama); ?>"
                                            width="80px"></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->npm); ?></td>
                                    <td><?php echo e($item->jk); ?></td>
                                    <td><?php echo e($item->tanggal_lahir); ?></td>
                                    <td><?php echo e($item->asal_sma); ?></td>
                                    <td><?php echo e($item->prodi->nama ?? '-'); ?></td>
                                    <td><?php echo e($item->prodi->fakultas->nama); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('mahasiswa.show', $item->id)); ?>" class="btn btn-info">Show</a>
                                        <a href="<?php echo e(route('mahasiswa.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                                        <form action="<?php echo e(route('mahasiswa.destroy', $item->id)); ?>" method="POST"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger show_confirm"
                                                data-nama="<?php echo e($item->nama); ?>" title='Delete'>Delete</button>

                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
        <!--end::Row-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>