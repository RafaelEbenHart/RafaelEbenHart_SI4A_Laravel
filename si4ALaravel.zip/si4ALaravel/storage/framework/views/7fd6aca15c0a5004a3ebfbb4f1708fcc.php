<?php $__env->startSection('title', 'Fakultas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!--begin::Row-->
        <div class="row">
            <div class="col-12">
                <!-- Default box -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Lihat Fakultas</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-collapse" title="Collapse">
                                <i data-lte-icon="expand" class="bi bi-plus-lg"></i>
                                <i data-lte-icon="collapse" class="bi bi-dash-lg"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-lte-toggle="card-remove" title="Remove">
                                <i class="bi bi-x-lg"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <table>
                            <tr>
                                <th>Nama</th>
                                <td><?php echo e($fakultas->nama); ?></td>
                            </tr>
                            <tr>
                                <th>Singkatan</th>
                                <td><?php echo e($fakultas->singkatan); ?></td>
                            </tr>
                            <tr>
                                <th>Dekan</th>
                                <td><?php echo e($fakultas->dekan); ?></td>
                            </tr>
                            <tr>
                                <th>Wakil Dekan</th>
                                <td><?php echo e($fakultas->wakil_dekan); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Niory\Documents\GitHub\RafaelEbenHart_SI4A_Laravel\si4ALaravel\resources\views/fakultas/show.blade.php ENDPATH**/ ?>